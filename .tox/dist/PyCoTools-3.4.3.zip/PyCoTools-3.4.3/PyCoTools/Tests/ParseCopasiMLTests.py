# -*- coding: utf-8 -*-
"""
 This file is part of PyCoTools.

 PyCoTools is free software: you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 PyCoTools is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public License
 along with PyCoTools.  If not, see <http://www.gnu.org/licenses/>.


Author: 
    Ciaran Welsh
Date:
    12/03/2017

 Object:
 
"""


import sys
import os
sys.path.append(os.path.abspath(".."))
for i in sys.path:
    print i

import PyCoTools
# import Tests

# print TestModels()

# class ParseCopasiML(unittest.TestCase):
#     def setUp(self):
#         self.model_file = os.path.join(os.getcwd(), 'test_model.cps')
#         with open(self.model_file, 'w') as f:
#             f.write(MODEL_STR.encode('utf-8'))
#
#     def test_read_copasi_file(self):
#         '''
#
#         '''
#         copasiModel = PyCoTools.pycopi.CopasiMLParser(self.model_file)
#         self.assertTrue(isinstance(copasiModel.copasiMLTree, lxml.etree._ElementTree))
#
#     # def test_write_copasi_file(self):
#     #     parser = PyCoTools.pycopi.CopasiMLParser(self.model_file)
#     #     parser.write_copasi_file(self.model_file, parser.copasiML)
#
#     def tearDown(self):
#         os.remove(self.model_file)
#

# if __name__ == '__main__':
#     unittest.main()
