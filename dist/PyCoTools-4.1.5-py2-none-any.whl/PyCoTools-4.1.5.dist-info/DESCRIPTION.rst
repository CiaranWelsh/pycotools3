Tools for using Copasi via Python and calculating profile likelihoods. See Github page and documentation for more details


