import PyCoTools



execfile('EvaluateOptimizationPerformanceTests.py')


#execfile('GetModelQuantitiesTests.py')


#execfile('InsertParameterTests.py')

#execfile('ParameterEstimationTests.py')


#execfile('ParsePEDataTests.py')



#execfile('PEPlotTests.py')


#execfile('PhasePlotTests.py')


#execfile('PlotBoxplotTests.py')


#execfile('PruneCopaiParameterTests.py')


#execfile('pydentify2_setup_tests.py')


#execfile('ReportTests.py')

#execfile('ScanTests.py')



#execfile('TimeCourseTests.py')

































