# -*- coding: utf-8 -*-
"""
Created on Wed Mar 08 15:59:58 2017

@author: b3053674
"""

import glob


for i in glob.glob('*.py'):
    print i
